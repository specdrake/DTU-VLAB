.. _news-page:

======
 News
======

.. include:: news.txt
