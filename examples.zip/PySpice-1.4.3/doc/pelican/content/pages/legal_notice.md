Title: Legal Notice

## Copyright and Intellectual Property

This website is protected by French and international legislation on royalties and intellectual property.

Unless otherwise specified the content of this website is licensed under Creative Commons by-nc-sa.

## Personal Data and Privacy

You can visit this site on Internet without providing your identity and personnal data about yourself.

Apart from the use of a tracker to measure the site audience.

## Publisher

**Fabrice SALVAIRE** pyspice AT fabrice-salvaire DOT fr

## Website Hosting

This web site is hosted by the OVH SAS society in France.
