There is no mailing list or forum actually, so you can either contact me or fill an issue on Github.

If you encounter an issue, please fill an issue.
