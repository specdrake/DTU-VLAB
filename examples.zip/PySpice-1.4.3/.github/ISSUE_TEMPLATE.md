### Environment (OS, Python version, PySpice version, simulator)

### Expected Behaviour

### Actual Behaviour

### Steps to reproduce the behaviour
