.. -*- Mode: rst -*-

.. _examples-page:

==========
 Examples
==========

The examples are classified by topics.

.. here comes examples/examples.rst
