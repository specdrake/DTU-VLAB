echo 'Enter'
echo '> tran 0.3m 3m'
echo '> plot V(2) V(7)'
ngspice example.cir
